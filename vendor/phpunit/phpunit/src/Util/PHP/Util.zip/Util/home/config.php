<?php

$METRI_TOKEN = "https://api.telegram.org/bot6637080701:AAEZ_LUJ7DQahqifuNWZpM-gv6xjUtbJec4";

$chat_id = "-4103435355";

// $reload = '3';

?>